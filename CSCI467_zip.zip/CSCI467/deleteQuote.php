<?php

  $username = "z1805962";
  $password = "1997Jun17";
  
  try 
  {
    $dsn = "mysql:host=courses;dbname=z1805962";
    $pdo = new PDO($dsn, $username, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
  }
  catch(PDOexception $e) 
  { //Handles the exception
  echo "Connection to database failed: " . $e->getMessage();
  } 

  $ordrID=$_REQUEST['ordrID'];
  $custID=$_REQUEST['custID'];

  $sql= "DELETE FROM customerQuotes WHERE ordrID='$ordrID' && custID='$custID'";
  $pdo->exec($sql);

  header("Location: hqPage.php");
  

?>

