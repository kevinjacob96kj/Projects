<!DOCTYPE html>
<html>
<head><title>Company Headquarters Page</title></head>
<body>
  <!--Change href link to login file-->
<center><p><a href="http://students.cs.niu.edu/~z1856135/login1.php">Login Page</a></p></center>
<!--Sanctioned Quotes are displayed-->
<center><h2> Customers' Finalized Quotes </h2></center>
<table width="100%" border="1" style="border-collapse:collapse;">
      <thead>
        <center>
          <tr>
            <th><strong>OrderID</strong></th>
            <th><strong>CustomerID</strong></th>
            <th><strong>Description</strong></th>
            <th><strong>Price</strong></th>
            <th><strong>Notes</strong></th>
            <th><strong>Status</strong></th>
            <th><strong>Edit</strong></th>
            <th><strong>Delete</strong></th></center>
          </tr>
        </center>
      </thead>


<?php

$username = "z1805962";
$password = "1997Jun17";

try 
{
  $dsn = "mysql:host=courses;dbname=z1805962";
  $pdo = new PDO($dsn, $username, $password);

  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
}
catch(PDOexception $e) 
{ //Handles the exception
  echo "Connection to database failed: " . $e->getMessage();
}

$sql = 'SELECT * FROM customerQuotes WHERE status="finalized";';

$result = $pdo->prepare($sql);
$result->execute();
$rows = $result->fetchAll();
    
foreach($rows as $row) 
{ 
  ?>
  <tr>
      <td align="center"><?php echo $row["ordrID"]; ?></td>

      <td align="center"><?php echo $row["custID"]; ?></td>

      <td align="center"><?php echo $row["description"]; ?></td>

      <td align="center"><?php echo $row["price"]; ?></td>

      <td align ="center"><?php echo $row["notes"]; ?></td>

      <td align ="center"><?php echo $row["status"]; ?></td>

      <td align="center"><a href="editHqPage.php?ordrID=<?php echo $row["ordrID"]; ?>&custID=<?php echo $row["custID"] ?>">Edit</a></td>
      
      <td align="center"><a href="deleteQuote.php?ordrID=<?php echo $row["ordrID"]; ?>&custID=<?php echo $row["custID"] ?>">Delete</a></td>
  </tr>

<?php } ?>

   </table>
  </body>
</html>

