<?php
  $username = "z1805962";
  $password = "1997Jun17";
  
  try 
  {
    $dsn = "mysql:host=courses;dbname=z1805962";
    $pdo = new PDO($dsn, $username, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
  }
  catch(PDOexception $e) 
  { //Handles the exception
  echo "Connection to database failed: " . $e->getMessage();
  }

?>

<!DOCTYPE html>
<html>
  <head><title>Update Status of Quotes</title></head>
  <body>
    <div class="form">
      <center><p><a href="http://students.cs.niu.edu/~z1805962/Quotes/hqPage.php">Back to Hq Page</a></p></center>
      <center><h2>Update Status</h2></center>
      
<?php

  $var = "";

  if(isset($_POST['new']) && $_POST['new'] == 1) 
  {
    $status = $_REQUEST['status'];
    $order = $_GET['ordrID'];
    $sql = "UPDATE customerQuotes SET status='$status' WHERE ordrID='$order'";
    $prepared = $pdo->prepare($sql);  
    $prepared->execute(); 

    $var = "<center>Information Updated</center> </br></br><center><a href='hqPage.php'>Go Back</a></center>";   
    echo '<p style="color:#301934;">'.$var.'</p>';
  }
  else 
  { ?>
    
 </div>
      <form name="form" method="post" action="">

      <input type="hidden" name="new" value="1" />
     
      <center><p><input type="text" name="status" placeholder="Change to Sanctioned" required /></p></center>

      <center><input name="submit" type="submit" value="Update Quote"></center>

      </form> 
      <?php 
  } ?>
  


    </div>
    </div> 
  </body>
</html>

